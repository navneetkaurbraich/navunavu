/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_final;
import java.sql.Connection;
import java.util.Scanner;
import java.sql.*;

/**
 *
 * @author kaurn
 * 
 * 
 */

class flight extends departuredate 
{
        static Connection conn;
                static PreparedStatement stmt;
                static ResultSet rs = null;
                static String USER = "root";
                static String PASS = "";
                static String name;
                static String password; 
        
       
        void display2() throws SQLException
            {
               
                 //super.display1();
                 try{
                     PreparedStatement Stmt = conn.prepareStatement("SELECT * FROM flight_list");
                     //rs = stmt.execute();
            
            
           rs = Stmt.executeQuery();
                 }
           catch(SQLException e){
            e.printStackTrace();
        }
           while(rs.next()){
              
              System.out.println("  Flight number : " + rs.getString(1) +
                       " Itinerary : " + rs.getString("itinary") +
                       " Departure date : " + rs.getString("dept_date") +
                        " Pilot Name: " + rs.getString("pilot_nm"));
           }
           
        }
                
            }
        
        
