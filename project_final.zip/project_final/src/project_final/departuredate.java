/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_final;
import java.sql.Connection;
import java.util.Scanner;
import java.sql.*;

/**
 *
 * @author kaurn
 */
public class departuredate {
    static Connection conn;
                static PreparedStatement stmt;
                static ResultSet rs = null;
                static String USER = "root";
                static String PASS = "";
                static String name;
                static String password; 
        void display1()
        {
            try{
            Scanner scanner1 = new Scanner(System.in);
            System.out.println("Enter Date:");
            String dt = scanner1.nextLine();
        
            System.out.println("Enter Time:");
            String tm = scanner1.nextLine();
            
            PreparedStatement Stmt1 = conn.prepareStatement("INSERT INTO departuredate_table VALUES(?,?)");
                
            Stmt1.setString(4, dt);
         
            Stmt1.setString(5, tm);
            
            Stmt1.executeUpdate();
         System.out.println("Entered Information Stored Successfully!....");
            }
            catch(SQLException e){
            e.printStackTrace();
            }
    
        }
}
