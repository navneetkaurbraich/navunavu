/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_final;
import java.sql.*;
import java.util.Scanner;


/**
 *
 * @author kaurn
 */


public class Project_final {
   
    public static void main(String[] args) throws SQLException  {
        // TODO code application logic here
        
        
        flight obj1=new flight();
       obj1.display2();
        
}
}



