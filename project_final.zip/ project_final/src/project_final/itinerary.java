package project_final;

import java.sql.*;
import java.util.Scanner;


class itinerary {
    static Connection conn;
                static PreparedStatement stmt;
                static ResultSet rs = null;
                static String USER = "root";
                static String PASS = "";
                static String name;
                static String password; 
    public void connectDB(){
        try{
            
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/mad3464", USER, PASS);
            
        }catch(Exception e){
            e.printStackTrace();
        }
     }   
    //String st_pt="",dt_pt="",nm="";
     public void display()
        {
            try{
        Scanner scanner1 = new Scanner(System.in);
        System.out.println("Enter Full Name:");
        String nm;
                nm = scanner1.nextLine();
        
        System.out.println("Enter Starting point:");
        String st_pt;
            st_pt = scanner1.nextLine();
        
            System.out.println("Enter Destination point:");
        String dt_pt;
            dt_pt = scanner1.nextLine();
            
            PreparedStatement Stmt1 = conn.prepareStatement("INSERT INTO itinerary_table VALUES(?,?,?)");

	// set param values

	Stmt1.setString(1, nm);

	Stmt1.setString(2, st_pt);
        
        Stmt1.setString(3, dt_pt);
        
        Stmt1.executeUpdate();
         System.out.println("Entered Information Stored Successfully!....");
        }
        catch(SQLException e){
            e.printStackTrace();
        }
        }
}