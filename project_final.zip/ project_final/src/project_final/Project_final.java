package project_final;
import java.sql.*;
import java.util.Scanner;

public class Project_final {
                static Connection conn;
                static PreparedStatement stmt;
                static ResultSet rs = null;
                static String USER = "root";
                static String PASS = "";
                static String name;
                static String password; 
   
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        connectDB();
        insertDB();
        
        itinerary obj2=new itinerary();
        obj2.connectDB();
        obj2.display();
         Departuredate obj = new Departuredate();
        obj.connectDB();
        obj.display1();
        flight obj1=new flight();
        obj1.connectDB();
        obj1.display2();
        seatreservation obj3 = new seatreservation();
        obj3.start();
        obj3.makeReservation();
        obj3.firstClassSeat();
        obj3.economySeat();
       
        
    }
    public static void connectDB(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/mad3464", USER, PASS);
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
        
    static void insertDB(){
        try{
    Scanner scanner = new Scanner(System.in);
    System.out.println("Enter Username:");
    String name = scanner.nextLine();
    System.out.println("Enter Password:");
    String password = scanner.nextLine();

            PreparedStatement Stmt = conn.prepareStatement("INSERT INTO login VALUES(?,?)");

	// set param values

	Stmt.setString(1, name);

	Stmt.setString(2, password);
	// 3. Execute SQL query

	Stmt.executeUpdate();
         System.out.println("You are  logged in......");          
        }
        
        catch(SQLException e){
            e.printStackTrace();
        }
    }
    
    
    
    
        
        
}
