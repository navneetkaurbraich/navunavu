package project_final;


import java.sql.Connection;
import java.util.Scanner;
import java.sql.*;
class Departuredate {
    
    static Connection conn;
                static PreparedStatement stmt;
                static ResultSet rs = null;
                static String USER = "root";
                static String PASS = "";
                static String name;
                static String password; 
        public void connectDB(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/mad3464", USER, PASS);
            
        }catch(Exception e){
            e.printStackTrace();
        }
     } 
        void display1()
        {
            try{
            Scanner scanner1 = new Scanner(System.in);
            System.out.println("Enter Date:");
            String dt = scanner1.nextLine();
            
            System.out.println("Enter Time:");
           String tm = scanner1.nextLine();
            
            PreparedStatement Stmt1 = conn.prepareStatement("INSERT INTO departuredate_table VALUES(?,?)");
                
            Stmt1.setString(1, dt);
         
            Stmt1.setString(2, tm);
            
            Stmt1.executeUpdate();
         System.out.println("Entered Information Stored Successfully!....");
            }
            catch(SQLException e){
            e.printStackTrace();
            }
        }
        
        
        
        
}
