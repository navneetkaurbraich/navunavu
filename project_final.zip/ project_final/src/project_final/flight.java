package project_final;


import project_final.Departuredate;
import java.sql.Connection;
import java.util.Scanner;
import java.sql.*;

class flight extends Departuredate 
{
        static Connection conn;
                static PreparedStatement stmt;
                static ResultSet rs = null;
                static String USER = "root";
                static String PASS = "";
                static String name;
                static String password; 
        
       public void connectDB(){
        try{
            
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/mad3464", USER, PASS);
            
        }catch(Exception e){
            e.printStackTrace();
        }
     } 
        void display2() throws SQLException
            {
               
                 //super.display1();
            try{
                PreparedStatement Stmt = conn.prepareStatement("SELECT * FROM flight_list");
                     //rs = stmt.execute();
           rs = Stmt.executeQuery();
                 }
           catch(SQLException e){
            e.printStackTrace();
        }
           while(rs.next()){
              
              System.out.println("  Flight number : " + rs.getString(1) +
                       " Itinerary : " + rs.getString("itinary") +
                       " Departure date : " + rs.getString("dept_date") +
                        " Pilot Name: " + rs.getString("pilot_nm"));
           }
           
        }
                
            }
        
        
